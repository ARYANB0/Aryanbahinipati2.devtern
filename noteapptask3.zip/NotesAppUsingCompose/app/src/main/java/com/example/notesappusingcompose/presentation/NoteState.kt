package com.example.notesappusingcompose.presentation

import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import com.example.notesappusingcompose.data.Note

data class NoteState
   ( var notes: List<Note> = emptyList(),

    val title:MutableState<String> = mutableStateOf(""),
    val disp:MutableState<String> = mutableStateOf("")
           )

